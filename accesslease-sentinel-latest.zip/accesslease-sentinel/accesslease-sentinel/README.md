# AccessLease Sentinel

Full local project: FastAPI backend plus a responsive web dashboard. Frontend
features include live overview metrics, finding search and severity filters,
evidence dialogs, direct/inherited/delegated permission paths, policy cards,
scan history, and an optional simulation date when running a scan.

## Where to save it

Keep the entire `accesslease-sentinel` folder together. A suggested permanent
location is `C:\Users\dell\Documents\AccessLease-Sentinel`. Copy or extract the
whole project there; do not move only `main.py`.

```text
accesslease-sentinel/
  Start.cmd
  README.md
  frontend/
    index.html
    styles.css
    app.js
  backend/
    main.py
    database.py
    models.py
    policy_engine.py
    schemas.py
    seed_data.py
    requirements.txt
    requirements-dev.txt
    test_integration.py
    accesslease.db       (created on startup; persistent data)
    .venv/               (created during local setup)
```

Double-click `Start.cmd` to create a local Python environment, install the
dependencies and run the site. First setup needs internet access. It uses the
available bundled Python on this PC, or the Python 3.12 launcher on another PC.
Keep the terminal window open and visit <http://127.0.0.1:8000/> once startup
completes. If another server already occupies port 8000, stop that server before
starting this copy. You can also use the VS Code commands below.

To move or back up a project with existing data, stop its server first and copy
the project including `backend/accesslease.db`. Recreate `.venv` in the new
location rather than copying the old environment. The download ZIP contains
source only; its demo database is created on first run. The current workspace
folder retains its existing database.

Frontend files are served by the same backend at `/` and `/assets`, so only one
server is required. Do not open `index.html` directly or use VS Code Live Server.
The layout uses local CSS/JavaScript with optional Google Fonts and system-font
fallbacks. No Node.js installation or frontend build command is needed.

The six supplied files are included unchanged in `backend/`. The new `main.py`
uses their existing database, Pydantic schemas, seeder and policy engine directly.

## Run in Windows VS Code (PowerShell terminal)

Open this `accesslease-sentinel` folder in VS Code. Use Python 3.11 or 3.12 for
the supplied dependency pins; the integration environment uses Python 3.12.

```powershell
cd backend
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

If `py` is unavailable but Python 3.12 is installed, replace the venv creation
command with `python -m venv .venv`. Running the environment's Python directly
avoids PowerShell activation/execution-policy errors.

On the current PC, `py` was not found. The following installed Python 3.12
runtime was used successfully for integration testing, and can create the venv:

```powershell
& 'C:\Users\dell\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m venv .venv
```

Open <http://127.0.0.1:8000/> for the dashboard or
<http://127.0.0.1:8000/docs> for API testing. Swagger's **Try it out** lets you exercise every endpoint.
Stop the server with Ctrl+C. Run from `backend` so the supplied sibling imports
resolve and the default SQLite database stays in `backend/accesslease.db`.

On the first startup, tables, demo data and an initial policy scan are created.
Subsequent startups preserve the data and existing scans. Seeding uses the
original seeder's user-count guard: if any users exist, it skips seeding entirely.
It does not repair a partly populated database.

## API

| Method | Path | Behavior |
| --- | --- | --- |
| GET | `/api/health` | API process health |
| POST | `/api/seed` | Seed demo data if empty; create first scan if needed |
| GET | `/api/dashboard` | Dashboard metrics; alias `/api/dashboard/metrics` |
| POST | `/api/scan` | New full scan; optional JSON `{"simulated_date":"2026-12-31"}` |
| GET | `/api/scans` | Scan history, newest first |
| GET | `/api/findings` | Latest completed scan by default; `scan_id` selects history |
| GET | `/api/findings/{id}` | Finding by numeric ID or `FND-...` identifier |
| GET | `/api/permissions` | Direct grant records, including revoked records |
| GET | `/api/permissions/effective` | Direct, inherited and delegated access paths |
| GET | `/api/users` | Users |
| GET | `/api/resources` | Resources |
| GET | `/api/policies` | Policies |
| GET | `/api/delegations` | Delegation records |
| GET | `/api/role-assignments` | Role assignments |

Findings support `severity`, `classification`, `status`, `user_id`, `department`
(the user's department), `offset`, and `limit`. Direct permissions support
`user_id`, `resource_id`, `status`, `offset`, and `limit`. Effective permissions
support `user_id` and `resource_id`. Lists return arrays; pagination defaults to
100 for findings and direct permissions, with a maximum of 1,000.

Example in a second PowerShell terminal:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/api/dashboard
Invoke-RestMethod -Method Post http://127.0.0.1:8000/api/scan
Invoke-RestMethod 'http://127.0.0.1:8000/api/findings?severity=CRITICAL'
Invoke-RestMethod 'http://127.0.0.1:8000/api/permissions/effective?user_id=3'
```

## Metric definitions and existing engine behavior

- Findings metrics use only the latest completed scan, including a simulated
  scan if that is the latest; previous scans remain available through `scan_id`.
- `total_active_permissions` counts effective access paths, including
  `PENDING_REVIEW`, following the supplied engine. A user/resource pair may
  contribute several paths. Expired access is still counted until deactivated.
- `expired_active_permissions` counts expired active direct, delegated and
  role-derived paths. It uses the latest scan's simulated date, or today's date.
- `overbroad_grants` counts latest-scan POL-007 findings; `ownerless_grants`
  counts current active/pending direct grants with missing or blank owners.
- The existing scan's `total_permissions_scanned` counts direct grants and
  delegations only. It will differ from the dashboard's effective-path count.
- Time-travel scans create findings without changing permission status/expiry.
- The original policy rules are preserved. This adds API integration, not a
  policy-engine correctness audit or additional detection rules.

## Configuration

`DATABASE_URL` is supported by the supplied database module. Default:
`sqlite:///./accesslease.db`. Set `$env:SEED_DEMO_DATA = "false"` before launching
to disable automatic demo seeding. Explicit `POST /api/seed` still works.

CORS allows localhost/127.0.0.1 frontend ports 3000 and 5173. This is a local
demo without authentication; keep the documented loopback binding. Use a
single server process: the write lock coordinates scans/seeding within that
process only.

## Integration tests

From `backend`, with the virtual environment already created:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m unittest -v test_integration
```

The tests use a separate temporary SQLite database. They cover startup,
restart and seed idempotency, scan history, dashboard consistency, all three
access sources, revoked-access exclusion, time travel, filters, validation,
lookup routes, and startup with automatic seeding disabled.

Validation: all six integration tests passed on Windows with Python 3.12.14,
the original pinned requirements, and HTTPX 0.25.2. The six supplied source
files also matched their original file hashes. Existing Pydantic/SQLAlchemy
deprecation warnings do not prevent these tests from passing.

Frontend verification: JavaScript syntax passed; the page and assets returned
HTTP 200; live API data loading, all five view renderers, severity filtering,
finding details and HTML escaping passed a DOM-stub smoke check. Automated
visual/browser interaction testing could not run because the browser tool's
runtime assets were unavailable. The frontend does not implement grant changes
or finding review mutations; it presents evidence and runs the existing scans.
